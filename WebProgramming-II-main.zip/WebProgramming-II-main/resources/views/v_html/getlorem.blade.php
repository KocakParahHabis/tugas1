<p>
    <b>Mengenal Huruf Tebal</b><br>
</p>
<p>
    <u>Mengenal Huruf Garis Bawah </u><br>
</p>
<p>
    <i>Mengenal Huruf Miring</i>
</p>