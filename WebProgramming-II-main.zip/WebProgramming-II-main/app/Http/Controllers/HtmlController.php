<?php 
namespace App\Http\Controllers; 
use Illuminate\Http\Request; 
 
class HtmlController extends Controller 
{ 
    public function getLorem() 
    { 
        return view('v_html.getlorem'); 
    } 
    
    public function gettabel()
    { 
        return view('v_html.gettabel'); 
    } 

    public function getform()
    { 
        return view('v_html.getform'); 
    } 
}